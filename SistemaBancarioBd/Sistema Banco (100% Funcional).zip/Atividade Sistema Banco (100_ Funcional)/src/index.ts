import * as leitor from "readline-sync";
import { ContaBancaria } from "./class/banco";
import banco from "./database/bd";

let usuarioatual: ContaBancaria | undefined;

function exibirMenuPrincipal(): number {
  console.log("\n****** MENU ******");
  console.log("1 - Acessar conta");
  console.log("2 - Criar conta");
  console.log("3 - Depositar");
  console.log("4 - Sacar");
  console.log("5 - Verificar saldo");
  console.log("6 - Extrato");
  console.log("0 - Sair");

  return leitor.questionInt("Escolha uma opcao: ");
}

async function acessoConta(): Promise<void> {
  const numConta = leitor.question("Insira o numero da sua conta: ");
  const senha = leitor.question("Insira sua senha: ");

  try {
    const resultados = await banco.execute("SELECT * FROM contas WHERE numeroConta = ? AND senha = ?", [numConta, senha]);
    if (resultados.length === 1) {
      const conta = new ContaBancaria(numConta, senha);
      usuarioatual = conta;
      console.log("Conta acessada com sucesso!");
    } else {
      console.log("Número de conta ou senha incorretos. Tente novamente.");
    }
  } catch (err) {
    console.log('Erro', err);
  }
}

async function criarConta(): Promise<void> {
  const numConta = leitor.question("Insira o numero da sua conta: ");
  const senha = leitor.question("Insira sua senha: ");
  const conta = new ContaBancaria(numConta, senha);
  usuarioatual = conta;
  await usuarioatual?.criarConta();
}

async function depositar(): Promise<void> {
  if (usuarioatual && usuarioatual.getSenha() === leitor.question("Digite sua senha:")) {
    const valorDepositar = leitor.questionFloat("Insira o valor a ser depositado: ");
    await usuarioatual?.depositar(valorDepositar);
  } else {
    console.log("Senha incorreta. Operação cancelada.");
  }
}

async function sacar(): Promise<void> {
  if (usuarioatual && usuarioatual.getSenha() === leitor.question("Digite sua senha:")) {
    const valorSacar = leitor.questionFloat("Insira o valor a ser retirado: ");
    await usuarioatual?.sacar(valorSacar);
  } else {
    console.log("Senha incorreta. Operação cancelada.");
  }
}

async function verificarSaldo(): Promise<void> {
  if (usuarioatual && usuarioatual.getSenha() === leitor.question("Digite sua senha:")) {
    await usuarioatual?.verificarSaldo();
  } else {
    console.log("Senha incorreta. Operação cancelada.");
  }
}

async function extrato(): Promise<void> {
  if (usuarioatual && usuarioatual.getSenha() === leitor.question("Digite sua senha:")) {
    await usuarioatual?.extrato();
  } else {
    console.log("Senha incorreta. Operação cancelada.");
  }
}

async function main(): Promise<void> {
  while (true) {
    const opcao: number = exibirMenuPrincipal();

    switch (opcao) {
      case 1:
        await acessoConta();
        break;
      case 2:
        await criarConta();
        break;
      case 3:
        await depositar();
        break;
      case 4:
        await sacar();
        break;
      case 5:
        await verificarSaldo();
        break;
      case 6:
        await extrato();
        break;
      case 0:
        console.log("Saindo...");
        return;
      default:
        console.log("Opção inválida!");
        break;
    }
  }
}

main();