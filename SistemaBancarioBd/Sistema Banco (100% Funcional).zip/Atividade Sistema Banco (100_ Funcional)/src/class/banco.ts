import banco from "../database/bd";

export class ContaBancaria {
  private saldo: number = 0;

  constructor(private numeroConta: string, private senha: string) {}

  public getSenha(): string {
    return this.senha;
  }

  async criarConta(): Promise<void> {
    try {
      await executeDatabaseQuery(`INSERT INTO Contas (numeroConta, senha, saldo) VALUES (?, ?, ?)`, [this.numeroConta, this.senha, this.saldo]);
      console.log(`\nConta ${this.numeroConta} criada com sucesso!\n`);
    } catch (err) {
      console.log('Erro', err);
    }
  }

  async depositar(valor: number): Promise<void> {
    try {
      if (valor > 0) {
        this.saldo += valor;
        await executeDatabaseQuery("UPDATE Contas SET saldo = ? WHERE numeroConta = ?", [this.saldo, this.numeroConta]);
        console.log(`Depósito de R$ ${valor.toFixed(2)} realizado. Novo saldo: R$ ${this.saldo.toFixed(2)}`);
      } else {
        console.log("O valor do depósito deve ser maior que zero!");
      }
    } catch (err) {
      console.log('Erro', err);
    }
  }

  async sacar(valor: number): Promise<void> {
    try {
      if (valor <= this.saldo) {
        this.saldo -= valor;
        await executeDatabaseQuery("UPDATE Contas SET saldo = ? WHERE numeroConta = ?", [this.saldo, this.numeroConta]);
        console.log(`Saque de R$ ${valor.toFixed(2)} realizado. Novo saldo: R$ ${this.saldo.toFixed(2)}`);
      } else {
        console.log("Saldo insuficiente para efetuar o saque!");
      }
    } catch (err) {
      console.log('Erro', err);
    }
  }

  async verificarSaldo(): Promise<void> {
    try {
      console.log(`Saldo atual: R$ ${this.saldo.toFixed(2)}`);
    } catch (err) {
      console.log('Erro', err);
    }
  }

  async extrato(): Promise<void> {
    try {
      const resultados = await executeDatabaseQuery("SELECT * FROM Contas WHERE numeroConta = ?", [this.numeroConta]);

      console.log(`Extrato da conta com o número ${this.numeroConta}:`);
      resultados.forEach(({ id_conta, numeroConta, saldo }: any) => {
        console.log(`Id: ${id_conta}, Número da Conta: ${numeroConta}, Saldo: ${saldo}`);
      });

    } catch (err) {
      console.error('Erro:', err);
    }
  }
}

async function executeDatabaseQuery(query: string, params: any[]): Promise<any> {
  try {
    const result = await banco.execute(query, params);
    return result;
  } catch (err) {
    console.error('Erro na execução da consulta:', err);
    throw err;
  }
}
