var mariadb = require("mariadb")

const banco = mariadb.createPool({
    host: "localhost",
    user: "root",
    port: 5000,
    password: "",
    database: "bancosql",
    waitForConnections: true,
    connectionLimit: 5,
})

export default banco


banco.execute(`
    CREATE TABLE IF NOT EXISTS Contas(
        id_conta INT AUTO_INCREMENT PRIMARY KEY,
        numeroConta VARCHAR(50) NOT NULL,
        senha VARCHAR(50) NOT NULL,
        saldo DECIMAL(10,2) NOT NULL
    );
`)